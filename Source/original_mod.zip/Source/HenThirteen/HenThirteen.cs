﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using Verse;

namespace HenThirteen
{
    public class ThingDef_HenThirteen : ThingDef
    {
        public float ZerkFactor = 0.5f;

    }

    public class HenThirteen : Pawn
    {
        public ThingDef_HenThirteen Def
        {
            get
            {
                //Case sensitive! If you use Def it will return Def, which is this getter. This will cause a never ending cycle and a stack overflow.
                return this.def as ThingDef_HenThirteen;
            }
        }
        public override void PreApplyDamage(ref DamageInfo dinfo, out bool absorbed)
        {
            base.PreApplyDamage(ref dinfo, out absorbed);

            if (this.Faction != Faction.OfPlayer)
            {
                Log.Message("not a player chicken 13");
                return;
            }

            if (!absorbed)
            {
                float DamageAbsorbed = 0f;
                HediffSet hediffSet = this.health.hediffSet;

                for (int i = 0; i < hediffSet.hediffs.Count; i++)
                {
                    if (hediffSet.hediffs[i] is Hediff_Injury)
                    {
                        DamageAbsorbed += hediffSet.hediffs[i].Severity;
                    }
                }

                float PercentHealth = Math.Min(DamageAbsorbed / (this.HealthScale * 25.0f), 0.99f);
                float rand = Rand.Value;
                 Log.Message("Not yet absorbed", true);
                 Log.Message(PercentHealth.ToString() + " " + DamageAbsorbed.ToString() + " " + this.HealthScale.ToString() + " " + rand.ToString(), true);
                absorbed = (rand <= (PercentHealth * Def.ZerkFactor));
                Log.Message("2nd chance absord result " + absorbed.ToString() + "    " + (PercentHealth * Def.ZerkFactor).ToString());

                if (absorbed)
                {
                    Messages.Message("Chicken 13's heroically shrugs off damage from "+ dinfo.Instigator.LabelShort.ToString()+"'s "+dinfo.Weapon.label.ToString(), MessageTypeDefOf.PositiveEvent);
                }

            }
            else
            {
                 Log.Message("absorbed to begin with  " + absorbed.ToString());
            }

        }
                   
    }

    public class IncidentWorker_RaidEnemy_HenThirteen : IncidentWorker_RaidEnemy
    {
       
        protected override bool TryExecuteWorker(IncidentParms parms)
        {
            Log.Message("We made it to new incidentworker_raidenemy yay!.  Number of raids is" + Find.StoryWatcher.statsRecord.numRaidsEnemy.ToString(), true);
            base.TryExecuteWorker(parms);

            if (Find.StoryWatcher.statsRecord.numRaidsEnemy == 1)
            {
                Log.Message("Here we are.  Number of raids is " + Find.StoryWatcher.statsRecord.numRaidsEnemy.ToString());
                Map map = (Map)parms.target;
                if (!RCellFinder.TryFindRandomPawnEntryCell(out IntVec3 result, map, CellFinder.EdgeRoadChance_Animal))
                {
                    return false;
                }

               foreach (Pawn p in PawnsFinder.AllMaps_SpawnedPawnsInFaction(Faction.OfPlayer))
               {
                    if (p.kindDef==DefDatabase<PawnKindDef>.GetNamed("HenThirteen"))
                    {
                       return false;
                    }
               }
                 
                    IntVec3 loc = CellFinder.RandomClosewalkCellNear(result, map, 12);
                    PawnKindDef kind = DefDatabase<PawnKindDef>.GetNamed("HenThirteen");
                    Pawn pawn = PawnGenerator.GeneratePawn(kind);
                    GenSpawn.Spawn(pawn, loc, map, Rot4.Random);
                    //PawnBioAndNameGenerator.GeneratePawnName(pawn, NameStyle.Full, "Hen 13");
                    pawn.Name = new NameTriple("Hen", "Hero Chicken", "13");
                    pawn.SetFaction(Faction.OfPlayer);
                    Find.LetterStack.ReceiveLetter("Hen 13 Joins", "A mythical hero of wide renown has sensed your danger and has decided to join your cause.  Hen Thirteen is on the scene", LetterDefOf.PositiveEvent, new TargetInfo(result, map));
                
            }
            return true;
        }
    }
}
